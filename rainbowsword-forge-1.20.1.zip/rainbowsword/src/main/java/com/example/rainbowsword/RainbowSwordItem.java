package com.example.rainbowsword;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public class RainbowSwordItem extends SwordItem {

    /**
     * Итоговый урон = 1 (базовый урон руки) + attackDamageBonus тира + модификатор меча.
     * Тут 1 + 0 + 999 = 1000.
     */
    private static final int DAMAGE_MODIFIER = 999;

    /**
     * Скорость атаки = 4.0 (база игрока) + модификатор.
     * -2.0 даёт итоговые 2.0.
     */
    private static final float SPEED_MODIFIER = -2.0F;

    private static final Tier RAINBOW_TIER = new Tier() {
        @Override
        public int getUses() {
            return 10000;
        }

        @Override
        public float getSpeed() {
            return 8.0F;
        }

        @Override
        public float getAttackDamageBonus() {
            return 0.0F;
        }

        @Override
        public int getLevel() {
            return 4;
        }

        @Override
        public int getEnchantmentValue() {
            return 25;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.EMPTY;
        }
    };

    public RainbowSwordItem() {
        super(RAINBOW_TIER, DAMAGE_MODIFIER, SPEED_MODIFIER,
                new Item.Properties().rarity(Rarity.EPIC).fireResistant());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    /** Название предмета переливается всеми цветами радуги. */
    @Override
    public Component getName(ItemStack stack) {
        String text = Component.translatable(this.getDescriptionId(stack)).getString();
        long time = System.currentTimeMillis() / 15L;
        MutableComponent result = Component.empty();
        for (int i = 0; i < text.length(); i++) {
            float hue = ((time + i * 25L) % 360L) / 360.0F;
            int rgb = Mth.hsvToRgb(hue, 0.85F, 1.0F);
            result.append(Component.literal(String.valueOf(text.charAt(i)))
                    .setStyle(Style.EMPTY.withColor(rgb)));
        }
        return result;
    }
}
