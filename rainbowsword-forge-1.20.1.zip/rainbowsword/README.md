# Rainbow Sword (Forge 1.20.1)

Радужный меч: урон 1000, скорость атаки 2.0.

## Сборка

Нужны Java 17 и Gradle 8.1+ (или gradlew из Forge MDK 1.20.1).

    gradle build

Готовый мод: `build/libs/rainbowsword-1.0.0.jar` — кладётся в папку `mods` рядом с Forge 1.20.1 (47.x).

Если используешь MDK: скопируй из него `gradlew`, `gradlew.bat` и папку `gradle/` в этот проект и запускай `./gradlew build`.

## Крафт

     D
    DND     D — алмаз, N — звезда Нижнего мира, S — палка
     S

Команда: `/give @s rainbowsword:rainbow_sword`
